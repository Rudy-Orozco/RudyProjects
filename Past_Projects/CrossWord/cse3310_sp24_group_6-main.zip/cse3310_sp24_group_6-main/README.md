# TicTacToe

```bash
% export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-11.0.18.0.9-0.3.ea.el8.x86_64
% mvn clean
% mvn compile
% mvn package
% mvn exec:java -Dexec.mainClass=uta.cse3310.App
% mvn clean compile package exec:java -Dexec.mainClass=uta.cse3310.App -DskipTests
```
Information on deployment:

https://www.programonaut.com/how-to-deploy-a-git-repository-to-a-server-using-github-actions/

cd cse3310_sp24_group_6
cd TicTacToe