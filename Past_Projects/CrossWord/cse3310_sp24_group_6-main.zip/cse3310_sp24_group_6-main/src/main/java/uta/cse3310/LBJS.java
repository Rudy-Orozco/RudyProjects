package uta.cse3310;

public class LBJS {
    LBJS() {};

    public Leaderboard LeadB;
    public int GameId;
    public int state;
}