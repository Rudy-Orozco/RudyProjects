//GROUP 6 - RUDY OROZCO

package uta.cse3310;

// A game can have 2, 3, or 4

public enum GameType {
    Game2, Game3, Game4;
}
 
