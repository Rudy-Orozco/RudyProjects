//GROUP 6 - RUDY OROZCO

package uta.cse3310;

// a word can be oriented in a specific way 
// (horizontal, vertical, diagonal, backwards)

public enum WordType {
    horizontal, bHorizontal, 
    vertical, bVertical,
    topLeftBottomRight, topRightBottomLeft,
    bottomLeftTopRight, bottomRightTopLeft;
}
 
