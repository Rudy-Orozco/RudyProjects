
package uta.cse3310;

public class ServerEvent {
    PlayerType YouAre;
    int GameId;
}

