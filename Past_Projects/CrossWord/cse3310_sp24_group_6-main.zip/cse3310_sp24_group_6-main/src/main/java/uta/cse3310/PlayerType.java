//GROUP 6 - RUDY OROZCO

package uta.cse3310;

// A player can be either player 0, 1, 2, 3, or 4.
/*From SREQ022:
 * Color is determined by chronological order.
 * First = blue
 * Second = red
 * Third = yellow
 * Fourth = green
 */

public enum PlayerType {
    Player0, Player1, Player2, Player3, Player4;
}
 
