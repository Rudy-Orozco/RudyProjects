package uta.cse3310;

import java.util.*;

public class messageBoard {
   String message;
   
   public messageBoard() {}
   
   public void generateMessage() {}   
}


