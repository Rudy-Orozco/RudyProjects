package uta.cse3310;

public class ServerEvent {
    PlayerType YouAre; // Either an XPLAYER or a YPLAYER
    int GameId;
    
}
