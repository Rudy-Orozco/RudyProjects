/* Rudy Orozco 1001864902*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "DrawTool.h"
#include "ListLib.h"
#include "FileLib.h"

int main(int argc, char *argv[])
{
    //ARRAY
    char Arry[MAXMAPSIZE][MAXMAPSIZE];

    //INITIALIZING VARIABLES
    char *tok;
    char drawtype, marker, cmmdline[15], chdrawtype[3], chmarker[3];
    int introw, intcol, dist, markerval, mapsize, offset = 0;

	//CA6 STUFF
	NODE *LinkedListHead, *TempPtr, Temp[20] = {};
	LinkedListHead = NULL;
	char strlet[4], tempch, *DrawCmd;

    //OTHER THINGS
    InitializeMap(Arry);
    PrintMap(Arry);

	//CA6 STUFF
	FILE *FH = OpenFile(argc, argv);
	ReadFileIntoLinkedList(FH, &LinkedListHead);
	printf("Please enter 1-3 letters: ");
	fgets(strlet, 3, stdin);

	for(int i = 0; i < strlen(strlet); i++)
	{
		tempch = toupper(strlet[i]);
		TempPtr = FindLetter(LinkedListHead, tempch, DrawCmd);

		//if(TempPtr)
		
		//printf("check %d\n", x++);
		strcpy(DrawCmd, TempPtr->DrawCommand); // HERE SEGFAULTS
		

		while(DrawCmd[0] != '\0')
		{	
			tok = strtok(DrawCmd,"(,)");
			drawtype = tok[0];

			tok = strtok(NULL,"(,)");
			introw = atoi(tok);
			
			tok = strtok(NULL,"(,)");
			intcol = atoi(tok);
			
			tok = strtok(NULL,"(,)");
			dist = atoi(tok);
			
			tok = strtok(NULL,"|");
			marker = tok[0];

			TempPtr = FindLetter(TempPtr, tempch, DrawCmd);
		
			while(drawtype != 'Q')
			{
				//if mark value not found, use X as default
				if(marker == '\n')
				{
					marker = 'X';
				}

				//Check for coordinate validity
				if((introw <= mapsize-1) && (introw >= 0) && (intcol <= mapsize-1) && (intcol >= 0)) 
				{
					if(drawtype == 'P') //if P, update array point with mark
					{
						DrawLine(Arry, introw, intcol, drawtype, 1, marker);
					}
					else if(drawtype == 'V') //if V, call function DrawLine()
					{
						if((introw + dist-1) > mapsize-1)
						{
							printf("That draw command is out of range");
						}
						else
						{
							DrawLine(Arry, introw, intcol, drawtype, dist, marker);
						}
					}
					else if(drawtype == 'H') //if H, call function DrawLine()
					{
						if((intcol + dist-1) > mapsize-1)
						{
							printf("That draw command is out of range");
						}
						else
						{
							DrawLine(Arry, introw, intcol, drawtype, dist, marker);
						}
					}
					else //if anything else, prompt unknown command
					{
						printf("Unknown command inputed");
					}
				}
				else
				{
					printf("That draw command is out of range");
				}

				PrintMap(Arry);
			}
		}
	}
	return 0;
}

/*//int main(int argc, char *argv[])
{
	

	char strlet[4], tempch, DrawCmd[6], *tok, mark;
	int  row, col, dist;

	FILE *FH = OpenFile(argc, argv);

	ReadFileIntoLinkedList(FH, &LinkedListHead);

	printf("Please enter 1-3 letters: ");
	scanf("%s", strlet);

	int x = 1;
	for(int i = 0; i < strlen(strlet); i++)
	{
		
		tempch = toupper(strlet[i]);
		TempPtr = FindLetter(LinkedListHead, tempch, DrawCmd);

		if(TempPtr)
		
			printf("check %d\n", x++);
			strncpy(DrawCmd, TempPtr->DrawCommand, 5); // HERE SEGFAULTS
		}

		printf("check %d\n", x++);

		while(DrawCmd[0] != '\0')
		{	
			tok = strtok(DrawCmd,"(,)");
			row = atoi(tok);
			
			tok = strtok(NULL,"(,)");
			col = atoi(tok);
			
			tok = strtok(NULL,"(,)");
			dist = atoi(tok);
			
			tok = strtok(NULL,"\0");
			mark = tok[0];

			TempPtr = FindLetter(LinkedListHead, tempch, DrawCmd);
		}
	}
}

//Use strtok() to parse out DrawComand only to check for Q
			tok = strtok(cmmdline, "(),");
			strcpy(chdrawtype, tok);
			drawtype = toupper(chdrawtype[0]);

		

			//Ask for another command
			printf("\nEnter draw command (enter Q to quit) "); //Prompt User
			fgets(cmmdline, 15, stdin); // Get string

			//Use strtok() to parse out DrawComand only to check for Q
			tok = strtok(cmmdline, "(),");
			strcpy(chdrawtype, tok);
			drawtype = toupper(chdrawtype[0]);

			//Continue Parsing out Values
			tok = strtok(NULL, "(),");
			introw = atoi(tok);
				
			tok = strtok(NULL, "(),");
			intcol = atoi(tok);

			tok = strtok(NULL, "(),");
			dist = atoi(tok);
				
			tok = strtok(NULL, "");
			strcpy(chmarker, tok);
			marker = chmarker[0];
*/